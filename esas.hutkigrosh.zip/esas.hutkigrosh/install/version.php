<?
$arModuleVersion = array(
	'VERSION' => '1.9.108',
	'VERSION_DATE' => '2020-05-01 12:00:00'
);