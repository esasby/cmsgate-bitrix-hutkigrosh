<?
// Важно! Без этого не будут работать события, т.к. нужно подключить автозагрузку
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/php_interface/include/sale_payment/esasby_hutkigrosh/init.php");
