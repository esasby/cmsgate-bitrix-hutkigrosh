<?php

namespace cmsgate_scope_bitrix_hutkigrosh;

use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\hutkigrosh\RegistryHutkigroshBitrix;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\CmsPlugin;
if (!\class_exists("cmsgate_scope_bitrix_hutkigrosh\\esas\\cmsgate\\CmsPlugin")) {
    require_once \dirname(__FILE__) . '/vendor/esas/cmsgate-core/src/esas/cmsgate/CmsPlugin.php';
    (new CmsPlugin(\dirname(__FILE__) . '/vendor', \dirname(__FILE__)))->setRegistry(new RegistryHutkigroshBitrix())->init();
}
