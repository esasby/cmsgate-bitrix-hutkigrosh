<?php

namespace cmsgate_scope_bitrix_hutkigrosh;

//подключаем только служебную часть пролога (для работы с CModule и CSalePaySystemAction), без визуальной части, чтобы не было вывода ненужного html
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\hutkigrosh\controllers\ControllerHutkigroshAlfaclick;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\utils\Logger;
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/php_interface/include/sale_payment/esasby_hutkigrosh/init.php";
if (!CModule::IncludeModule("sale")) {
    return;
}
try {
    $controller = new ControllerHutkigroshAlfaclick();
    $controller->process();
} catch (\Throwable $e) {
    Logger::getLogger("alfaclick")->error("Exception: ", $e);
}
