<?
$arModuleVersion = array(
	'VERSION' => '3.12.1',
	'VERSION_DATE' => '2020-08-24 12:00:00'
);