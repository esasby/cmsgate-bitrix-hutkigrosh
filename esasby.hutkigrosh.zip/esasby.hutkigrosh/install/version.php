<?
$arModuleVersion = array(
	'VERSION' => '3.0.2',
	'VERSION_DATE' => '2020-08-24 12:00:00'
);