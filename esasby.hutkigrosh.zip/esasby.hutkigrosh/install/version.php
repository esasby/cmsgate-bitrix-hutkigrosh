<?
$arModuleVersion = array(
	'VERSION' => '3.13.1',
	'VERSION_DATE' => '2020-10-16 12:00:00'
);