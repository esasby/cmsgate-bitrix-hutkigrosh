<?
$arModuleVersion = array(
	'VERSION' => '3.14.1',
	'VERSION_DATE' => '2021-01-14 12:00:00'
);
