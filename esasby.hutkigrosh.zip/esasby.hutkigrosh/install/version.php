<?
$arModuleVersion = array(
	'VERSION' => '3.15.0',
	'VERSION_DATE' => '2021-06-11 12:00:00'
);