<?
$arModuleVersion = array(
	'VERSION' => '3.0.0',
	'VERSION_DATE' => '2020-08-18 12:00:00'
);