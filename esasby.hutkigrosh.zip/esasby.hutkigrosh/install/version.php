<?
$arModuleVersion = array(
	'VERSION' => '3.13.0',
	'VERSION_DATE' => '2020-09-16 12:00:00'
);