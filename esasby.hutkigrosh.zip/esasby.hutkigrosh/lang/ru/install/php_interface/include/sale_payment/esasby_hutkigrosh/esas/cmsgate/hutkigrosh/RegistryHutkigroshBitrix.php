<?php

use esas\cmsgate\view\admin\AdminViewFields;

$MESS[AdminViewFields::ADMIN_PAYMENT_METHOD_NAME] = "Прием платежей через ЕРИП (ХуткiГрош)";
$MESS[AdminViewFields::ADMIN_PAYMENT_METHOD_DESCRIPTION] = "Выставление пользовательских счетов в ЕРИП";