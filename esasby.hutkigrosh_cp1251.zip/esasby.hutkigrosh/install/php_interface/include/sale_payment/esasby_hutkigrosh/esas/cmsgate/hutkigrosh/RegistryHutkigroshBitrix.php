<?php

/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 01.10.2018
 * Time: 12:05
 */
namespace cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\hutkigrosh;

use Bitrix\Main\Localization\Loc;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\CmsConnectorBitrix;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\descriptors\ModuleDescriptor;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\descriptors\VendorDescriptor;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\descriptors\VersionDescriptor;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\hutkigrosh\view\client\CompletionPanelHutkigroshBitrix;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\Registry;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\view\admin\AdminViewFields;
use CMain;
use COption;
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\view\admin\ConfigFormBitrix;
Loc::loadMessages(__FILE__);
class RegistryHutkigroshBitrix extends RegistryHutkigrosh
{
    public function __construct()
    {
        $this->cmsConnector = new CmsConnectorBitrix();
        $this->paysystemConnector = new PaysystemConnectorHutkigrosh();
    }
    /**
     * ������������� ��� ��������� ���������
     * @return RegistryHutkigroshBitrix
     */
    public static function getRegistry()
    {
        return parent::getRegistry();
    }
    /**
     * @throws \Exception
     */
    public function createConfigForm()
    {
        $managedFields = $this->getManagedFieldsFactory()->getManagedFieldsExcept(AdminViewFields::CONFIG_FORM_COMMON, [ConfigFieldsHutkigrosh::shopName(), ConfigFieldsHutkigrosh::paymentMethodName(), ConfigFieldsHutkigrosh::paymentMethodNameWebpay(), ConfigFieldsHutkigrosh::paymentMethodDetails(), ConfigFieldsHutkigrosh::paymentMethodDetailsWebpay()]);
        $configForm = new ConfigFormBitrix(AdminViewFields::CONFIG_FORM_COMMON, $managedFields);
        return $configForm;
    }
    function getUrlAlfaclick($orderWrapper)
    {
        return "/bitrix/tools/sale_ps_hutkigrosh_ajax.php";
    }
    function getUrlWebpay($orderWrapper)
    {
        global $APPLICATION;
        return (CMain::IsHTTPS() ? "https" : "http") . "://" . (\defined("SITE_SERVER_NAME") && \strlen(SITE_SERVER_NAME) > 0 ? SITE_SERVER_NAME : COption::GetOptionString("main", "server_name", "")) . $APPLICATION->GetCurUri();
    }
    public function createModuleDescriptor()
    {
        return new ModuleDescriptor(
            "esasby.hutkigrosh",
            // ��� ������ ��������� � ����� ������� � �������
            new VersionDescriptor("3.15.0", "2021-06-08"),
            "����� �������� ����� ���� (����i����)",
            "https://bitbucket.org/esasby/cmsgate-bitrix-hutkigrosh/src/master/",
            VendorDescriptor::esas(),
            "����������� ���������������� ������ � ����"
        );
    }
    public function getCompletionPanel($orderWrapper)
    {
        return new CompletionPanelHutkigroshBitrix($orderWrapper);
    }
}
