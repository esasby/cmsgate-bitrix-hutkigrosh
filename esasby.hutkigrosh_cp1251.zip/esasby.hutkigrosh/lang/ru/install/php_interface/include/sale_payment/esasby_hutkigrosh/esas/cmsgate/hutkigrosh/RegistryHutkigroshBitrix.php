<?php

namespace cmsgate_scope_bitrix_hutkigrosh;

/**
 * Используется встроенный механизм локализации bitrix, т.к. при создании ModuleDescriptor нельзя использовать
 * Registry->getTranslator (возникает бесконечная рекурсия)
 */
use cmsgate_scope_bitrix_hutkigrosh\esas\cmsgate\view\admin\AdminViewFields;
$MESS['hutkigrosh_payment_method_name'] = "Прием платежей через ЕРИП (ХуткiГрош)";
$MESS['hutkigrosh_payment_method_description'] = "Выставление пользовательских счетов в ЕРИП";
